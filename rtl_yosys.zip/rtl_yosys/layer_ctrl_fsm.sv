// ===========================================================================
// Module:  layer_ctrl_fsm.sv
// Project: AI Inference Accelerator SoC
// Author:  John Bagshaw, Senior FPGA Design Engineer
// Date:    February 2026
//
// Description:
//   11-state FSM orchestrating the complete inference datapath. Manages
//   tiled execution across IC (input channel), OC (output channel), and
//   spatial dimensions. Includes:
//     - Layer descriptor loading and validation
//     - Weight SRAM bank management (ping-pong)
//     - Activation streaming control
//     - Pipeline drain timing
//     - Tile counter advancement (IC → OC → spatial → next layer)
//     - Timeout watchdog with error recovery
//     - 8 hardware performance counters
//
// Tiling Strategy (weight-stationary):
//   For each spatial tile:
//     For each OC tile (out_channels / ARRAY_ROWS):
//       For each IC tile (in_channels / ARRAY_COLS):
//         1. Load weights [ARRAY_ROWS × ARRAY_COLS] into SRAM
//         2. Stream activations [spatial × ARRAY_COLS] through array
//         3. Accumulate partial sums across IC tiles
//       4. Requantize accumulated results
//       5. Output quantized tile
//
// Yosys compatibility:
//   layer_desc_t is a packed 68-bit struct in pkg_accelerator.sv.
//   Yosys does not accept the package typedef as a module-port/internal
//   variable type in this flow, so the descriptor crosses this module
//   boundary as a packed vector and is unpacked into explicit registers.
//
// Compatibility: Yosys, Verilator 5.x, VCS, QuestaSim
// ===========================================================================

`timescale 1ns / 1ps

import pkg_accelerator::*;

module layer_ctrl_fsm
(
  input  logic                          clk,
  input  logic                          rst_n,

  // External control
  input  logic                          start,
  input  logic                          abort_req,
  output logic                          busy,
  output logic                          done,

  // Layer descriptor input
  // Packed representation of layer_desc_t:
  // [67:52] in_channels
  // [51:36] out_channels
  // [35:20] spatial_size
  // [19:15] shift_amount
  // [14:7]  zero_point
  // [6]     relu_enable
  // [5:0]   reserved
  input logic [67:0] layer_desc_in_packed,
  input  logic                          layer_desc_valid,
  output logic                          layer_desc_ready,

  // SRAM control
  output logic                          sram_rd_en,
  output logic [SRAM_ADDR_W-1:0]        sram_rd_addr,
  output logic                          sram_bank_swap,

  // Weight load control (to external DMA)
  output logic                          wgt_load_start,
  input  logic                          wgt_load_done,

  // Activation input control
  output logic                          act_input_enable,
  output logic                          act_input_accept,
  output logic                          act_input_flush,

  // Systolic array control
  output logic                          array_enable,
  output logic                          array_clear_acc,
  output logic                          array_valid_reset,
  output logic                          array_data_valid,

  // Quantize control
  output logic                          quant_enable,
  output logic                          quant_relu_en,
  output logic [4:0]                    quant_shift,
  output logic signed [OUT_WIDTH-1:0]   quant_zero_point,

  // Output control
  output logic                          output_data_valid,
  output logic                          output_data_last,
  input  logic                          output_accepted,

  // Status
  output logic [3:0]                    current_state,
  output logic                          error_flag,
  output logic [3:0]                    error_code,

  // Performance counters
  output logic [32*NUM_PERF_CTRS-1:0] perf_counters_packed
);

  // -------------------------------------------------------------------------
  // FSM State Register
  // -------------------------------------------------------------------------
  logic [3:0] state_reg, state_next;

  // -------------------------------------------------------------------------
  // Layer Descriptor Registers
  // -------------------------------------------------------------------------
  // Explicit fields replace internal layer_desc_t variable for Yosys
  // compatibility while preserving the exact packed descriptor semantics.
  logic [15:0] layer_in_channels;
  logic [15:0] layer_out_channels;
  logic [15:0] layer_spatial_size;
  logic [4:0]  layer_shift_amount;
  logic signed [7:0] layer_zero_point;
  logic        layer_relu_enable;
  logic        desc_loaded;

  // -------------------------------------------------------------------------
  // Tile Counters
  // -------------------------------------------------------------------------
  logic [15:0] ic_tile_idx;
  logic [15:0] oc_tile_idx;

  /* verilator lint_off UNUSEDSIGNAL */
  logic [15:0] spatial_idx;
  /* verilator lint_on UNUSEDSIGNAL */

  logic [15:0] ic_tiles_total;
  logic [15:0] oc_tiles_total;
  logic        last_ic_tile;
  logic        last_oc_tile;

  /* verilator lint_off UNUSEDSIGNAL */
  logic        last_spatial;
  /* verilator lint_on UNUSEDSIGNAL */

  assign ic_tiles_total =
      layer_in_channels >> $clog2(TILE_COLS);

  assign oc_tiles_total =
      layer_out_channels >> $clog2(TILE_ROWS);

  assign last_ic_tile =
      (ic_tile_idx == ic_tiles_total - 1);

  assign last_oc_tile =
      (oc_tile_idx == oc_tiles_total - 1);

  assign last_spatial =
      (spatial_idx >= (layer_spatial_size - 16'd1));

  // -------------------------------------------------------------------------
  // Pipeline Drain Counter
  // -------------------------------------------------------------------------
  logic [$clog2(TOTAL_LATENCY+1):0] drain_cnt;
  logic                              drain_done;

  assign drain_done =
      (drain_cnt >= TOTAL_LATENCY[$clog2(TOTAL_LATENCY+1):0]);

  // -------------------------------------------------------------------------
  // Weight Address Counter
  // -------------------------------------------------------------------------
  logic [SRAM_ADDR_W-1:0] wgt_addr_cnt;
  logic                    wgt_addr_done;

  localparam COMPUTE_CYCLES = ARRAY_ROWS + 2;

  logic [$clog2(COMPUTE_CYCLES+1):0] compute_cnt;
  logic                               compute_done;

  assign wgt_addr_done =
      (wgt_addr_cnt >= ARRAY_ROWS[SRAM_ADDR_W-1:0]);

  assign compute_done =
      (compute_cnt >=
       COMPUTE_CYCLES[$clog2(COMPUTE_CYCLES+1):0]);

  // -------------------------------------------------------------------------
  // Watchdog Timer
  // -------------------------------------------------------------------------
  logic [31:0] watchdog_cnt;
  logic        watchdog_timeout;

  assign watchdog_timeout =
      (watchdog_cnt >= WATCHDOG_CYCLES);

  // -------------------------------------------------------------------------
  // Error Register
  // -------------------------------------------------------------------------
  logic        err_flag_reg;
  logic [3:0]  err_code_reg;

  assign error_flag = err_flag_reg;
  assign error_code = err_code_reg;

  // -------------------------------------------------------------------------
  // FSM Next-State Logic
  // -------------------------------------------------------------------------
  always_comb begin
    state_next = state_reg;

    case (state_reg)

      FSM_IDLE: begin
        if (start)
          state_next = FSM_LOAD_DESC;
      end

      FSM_LOAD_DESC: begin
        if (layer_desc_valid)
          state_next = FSM_LOAD_WEIGHTS;
        else if (watchdog_timeout)
          state_next = FSM_IDLE;
      end

      FSM_LOAD_WEIGHTS: begin
        if (wgt_load_done)
          state_next = FSM_LOAD_ACT;
        else if (watchdog_timeout)
          state_next = FSM_IDLE;
      end

      FSM_LOAD_ACT: begin
        state_next = FSM_COMPUTE;
      end

      FSM_COMPUTE: begin
        if (compute_done)
          state_next = FSM_DRAIN;
        else if (watchdog_timeout)
          state_next = FSM_IDLE;
      end

      FSM_DRAIN: begin
        if (drain_done) begin
          if (last_ic_tile)
            state_next = FSM_QUANT;
          else
            state_next = FSM_NEXT_TILE;
        end
      end

      FSM_QUANT: begin
        state_next = FSM_STORE_OUTPUT;
      end

      FSM_STORE_OUTPUT: begin
        if (output_accepted) begin
          if (last_spatial && last_ic_tile)
            state_next = FSM_NEXT_TILE;
          else if (!last_spatial)
            state_next = FSM_LOAD_ACT;
          else
            state_next = FSM_NEXT_TILE;
        end else if (watchdog_timeout)
          state_next = FSM_IDLE;
      end

      FSM_NEXT_TILE: begin
        if (last_oc_tile && last_ic_tile)
          state_next = FSM_NEXT_LAYER;
        else
          state_next = FSM_LOAD_ACT;
      end

      FSM_NEXT_LAYER: begin
        state_next = FSM_DONE;
      end

      FSM_DONE: begin
        state_next = FSM_DONE;
      end

      default: begin
        state_next = FSM_IDLE;
      end

    endcase

    // Abort overrides everything
    if (abort_req)
      state_next = FSM_IDLE;
  end

  // -------------------------------------------------------------------------
  // FSM State Register & Datapath Control
  // -------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin

    if (!rst_n) begin

      state_reg          <= FSM_IDLE;
      desc_loaded        <= 1'b0;

      // Layer descriptor fields
      layer_in_channels  <= '0;
      layer_out_channels <= '0;
      layer_spatial_size <= '0;
      layer_shift_amount <= '0;
      layer_zero_point   <= '0;
      layer_relu_enable  <= 1'b0;

      ic_tile_idx        <= '0;
      oc_tile_idx        <= '0;
      spatial_idx        <= '0;
      drain_cnt          <= '0;
      wgt_addr_cnt       <= '0;
      compute_cnt        <= '0;
      watchdog_cnt       <= '0;
      err_flag_reg       <= 1'b0;
      err_code_reg       <= ERR_NONE;

    end else begin

      state_reg <= state_next;

      // Watchdog: reset on state transition, count otherwise
      if (state_reg != state_next)
        watchdog_cnt <= '0;
      else
        watchdog_cnt <= watchdog_cnt + 1;

      // Error detection
      if (watchdog_timeout &&
          state_reg != FSM_IDLE &&
          state_reg != FSM_DONE) begin

        err_flag_reg <= 1'b1;
        err_code_reg <= ERR_TIMEOUT;

      end

      case (state_reg)

        FSM_IDLE: begin
          if (start) begin
            ic_tile_idx  <= '0;
            oc_tile_idx  <= '0;
            spatial_idx  <= '0;
            drain_cnt    <= '0;
            wgt_addr_cnt <= '0;
            compute_cnt  <= '0;
            err_flag_reg <= 1'b0;
            err_code_reg <= ERR_NONE;
          end
        end

        FSM_LOAD_DESC: begin
          if (layer_desc_valid) begin

            // Exact unpacking of the original packed layer_desc_t.
            layer_in_channels  <= layer_desc_in_packed[67:52];
            layer_out_channels <= layer_desc_in_packed[51:36];
            layer_spatial_size <= layer_desc_in_packed[35:20];
            layer_shift_amount <= layer_desc_in_packed[19:15];
            layer_zero_point   <=
                $signed(layer_desc_in_packed[14:7]);
            layer_relu_enable  <= layer_desc_in_packed[6];

            desc_loaded <= 1'b1;

          end
        end

        FSM_LOAD_WEIGHTS: begin
          if (state_next == FSM_LOAD_ACT)
            wgt_addr_cnt <= '0;
        end

        FSM_LOAD_ACT: begin
          if (!wgt_addr_done)
            wgt_addr_cnt <= wgt_addr_cnt + 1;
        end

        FSM_COMPUTE: begin

          if (!wgt_addr_done)
            wgt_addr_cnt <= wgt_addr_cnt + 1;

          compute_cnt <= compute_cnt + 1;

        end

        FSM_DRAIN: begin
          drain_cnt <= drain_cnt + 1;
        end

        FSM_QUANT: begin
          drain_cnt <= '0;
        end

        FSM_STORE_OUTPUT: begin

          if (output_accepted && !last_spatial) begin

            wgt_addr_cnt <= '0;
            compute_cnt  <= '0;
            drain_cnt    <= '0;
            spatial_idx  <= spatial_idx + 16'd1;
            ic_tile_idx  <= '0;

          end

        end

        FSM_NEXT_TILE: begin

          wgt_addr_cnt <= '0;
          compute_cnt  <= '0;
          drain_cnt    <= '0;

          if (!last_ic_tile) begin

            ic_tile_idx <= ic_tile_idx + 1;

          end else begin

            ic_tile_idx <= '0;
            spatial_idx <= '0;

            if (!last_oc_tile)
              oc_tile_idx <= oc_tile_idx + 1;

          end

        end

        FSM_NEXT_LAYER: begin
          oc_tile_idx <= '0;
          ic_tile_idx <= '0;
        end

        default: ;

      endcase

    end

  end

  // -------------------------------------------------------------------------
  // Output Control Signals
  // -------------------------------------------------------------------------
  assign current_state =
      state_reg;

  assign busy =
      (state_reg != FSM_IDLE) &&
      (state_reg != FSM_DONE);

  assign done =
      (state_reg == FSM_DONE);

  assign layer_desc_ready =
      (state_reg == FSM_LOAD_DESC);

  // -------------------------------------------------------------------------
  // SRAM Base Address for Tiled Weight Access
  // -------------------------------------------------------------------------
  // All weight tiles are pre-loaded into SRAM by DMA at the start.
  //
  // Base address =
  //   (oc_tile * n_ic_tiles + ic_tile) * ARRAY_ROWS
  // -------------------------------------------------------------------------
  logic [SRAM_ADDR_W-1:0] sram_rd_base;

  assign sram_rd_base =
      SRAM_ADDR_W'(oc_tile_idx * ic_tiles_total + ic_tile_idx)
      * SRAM_ADDR_W'(ARRAY_ROWS);

  assign sram_rd_en =
      ((state_reg == FSM_COMPUTE) ||
       (state_reg == FSM_LOAD_ACT)) &&
      !wgt_addr_done;

  assign sram_rd_addr =
      sram_rd_base + wgt_addr_cnt;

  assign sram_bank_swap =
      (state_reg == FSM_LOAD_WEIGHTS &&
       state_next == FSM_LOAD_ACT);

  assign wgt_load_start =
      (state_reg == FSM_LOAD_WEIGHTS) &&
      (state_next == FSM_LOAD_WEIGHTS);

  assign act_input_enable =
      (state_reg == FSM_COMPUTE) ||
      (state_reg == FSM_LOAD_ACT) ||
      (state_reg == FSM_DRAIN);

  assign act_input_accept =
      (state_reg == FSM_COMPUTE);

  assign act_input_flush =
      (state_reg == FSM_IDLE) ||
      (state_reg == FSM_NEXT_TILE) ||
      (state_reg == FSM_STORE_OUTPUT);

  assign array_enable =
      (state_reg == FSM_COMPUTE) ||
      (state_reg == FSM_DRAIN);

  assign array_clear_acc =
      ((state_reg == FSM_LOAD_WEIGHTS) &&
       (ic_tile_idx == 0)) ||
      ((state_reg == FSM_LOAD_ACT) &&
       (ic_tile_idx == 0));

  assign array_valid_reset =
      (state_reg == FSM_LOAD_ACT);

  assign array_data_valid =
      (state_reg == FSM_COMPUTE);

  // -------------------------------------------------------------------------
  // Quantization Control
  // -------------------------------------------------------------------------
  assign quant_enable =
      ((state_reg == FSM_DRAIN) && last_ic_tile) ||
      (state_reg == FSM_QUANT) ||
      (state_reg == FSM_STORE_OUTPUT);

  assign quant_relu_en =
      desc_loaded ? layer_relu_enable : 1'b0;

  assign quant_shift =
      desc_loaded ? layer_shift_amount : 5'd0;

  assign quant_zero_point =
      desc_loaded ? layer_zero_point : 8'sd0;

  // -------------------------------------------------------------------------
  // Output Control
  // -------------------------------------------------------------------------
  assign output_data_valid =
      (state_reg == FSM_STORE_OUTPUT) ||
      (state_reg == FSM_DRAIN) ||
      (state_reg == FSM_QUANT);

  assign output_data_last =
      (state_reg == FSM_STORE_OUTPUT) &&
      last_oc_tile &&
      last_ic_tile &&
      last_spatial;

  // -------------------------------------------------------------------------
  // Performance Counters (8 × 32-bit)
  // -------------------------------------------------------------------------
  logic [31:0] perf_ctr_reg [NUM_PERF_CTRS];

  always_ff @(posedge clk or negedge rst_n) begin

    if (!rst_n) begin

      perf_ctr_reg[0] <= '0;
      perf_ctr_reg[1] <= '0;
      perf_ctr_reg[2] <= '0;
      perf_ctr_reg[3] <= '0;
      perf_ctr_reg[4] <= '0;
      perf_ctr_reg[5] <= '0;
      perf_ctr_reg[6] <= '0;
      perf_ctr_reg[7] <= '0;

    end else if (state_reg == FSM_IDLE && start) begin

      perf_ctr_reg[0] <= '0;
      perf_ctr_reg[1] <= '0;
      perf_ctr_reg[2] <= '0;
      perf_ctr_reg[3] <= '0;
      perf_ctr_reg[4] <= '0;
      perf_ctr_reg[5] <= '0;
      perf_ctr_reg[6] <= '0;
      perf_ctr_reg[7] <= '0;

    end else if (busy) begin

      // Total cycles
      perf_ctr_reg[0] <= perf_ctr_reg[0] + 1;

      // MAC active
      if (state_reg == FSM_COMPUTE)
        perf_ctr_reg[1] <= perf_ctr_reg[1] + 1;

      // MAC stall
      if (state_reg == FSM_STORE_OUTPUT &&
          !output_accepted)
        perf_ctr_reg[2] <= perf_ctr_reg[2] + 1;

      // AXI read beats
      if (act_input_enable)
        perf_ctr_reg[3] <= perf_ctr_reg[3] + 1;

      // AXI write beats
      if (state_reg == FSM_STORE_OUTPUT &&
          output_accepted)
        perf_ctr_reg[4] <= perf_ctr_reg[4] + 1;

      // Layers done
      if (state_reg == FSM_NEXT_LAYER)
        perf_ctr_reg[5] <= perf_ctr_reg[5] + 1;

      // Tiles done
      if (state_reg == FSM_NEXT_TILE)
        perf_ctr_reg[6] <= perf_ctr_reg[6] + 1;

      // Errors
      if (watchdog_timeout)
        perf_ctr_reg[7] <= perf_ctr_reg[7] + 1;

    end

  end

  // -------------------------------------------------------------------------
  // Performance Counter Outputs
  // -------------------------------------------------------------------------
genvar ci;

generate
  for (ci = 0;
       ci < NUM_PERF_CTRS;
       ci = ci + 1) begin : gen_perf_out

    assign perf_counters_packed[ci*32 +: 32] =
        perf_ctr_reg[ci];

  end
endgenerate

endmodule