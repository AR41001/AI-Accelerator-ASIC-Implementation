// ============================================================================
// ASIC SRAM bank wrapper
//
// Implements one logical 1024 x 64-bit memory bank using
// eight sky130_sram_1kbyte_1rw1r_8x1024_8 hard macros.
//
// Baseline implementation deliberately uses only Port 0 (RW).
// Port 1 is disabled and reserved for future architectural investigation.
// ============================================================================

module sky130_sram_bank (
    input  logic        clk,

    input  logic        rd_en,
    input  logic [9:0]  rd_addr,
    output logic [63:0] rd_data,

    input  logic        wr_en,
    input  logic [9:0]  wr_addr,
    input  logic [63:0] wr_data
);

    // Port 0 is shared between read and write.
    //
    // Macro controls are active-low:
    //   csb0 = 0 -> access enabled
    //   web0 = 0 -> write
    //   web0 = 1 -> read

    wire        macro_csb;
    wire        macro_web;
    wire [9:0]  macro_addr;

    assign macro_csb  = ~(rd_en | wr_en);
    assign macro_web  = ~wr_en;
    assign macro_addr = wr_en ? wr_addr : rd_addr;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : gen_sram_lane

            sky130_sram_1kbyte_1rw1r_8x1024_8 u_sram (
                // Port 0: baseline read/write port
                .clk0   (clk),
                .csb0   (macro_csb),
                .web0   (macro_web),
                .wmask0 (1'b1),
                .addr0  (macro_addr),
                .din0   (wr_data[i*8 +: 8]),
                .dout0  (rd_data[i*8 +: 8]),

                // Port 1 deliberately unused in baseline
                .clk1   (clk),
                .csb1   (1'b1),
                .addr1  (10'b0),
                .dout1  ()
            );

        end
    endgenerate

endmodule
